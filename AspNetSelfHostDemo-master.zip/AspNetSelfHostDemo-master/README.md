# ASP.NET Self Host Demo Application
This is a sample project for a series of blog posts on http://codeopinion.com
